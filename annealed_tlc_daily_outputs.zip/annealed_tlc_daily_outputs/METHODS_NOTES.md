# Daily geometric real-data protocol

Data: https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page
Window: 2019-07 through 2020-12.  Event date for descriptive contrasts: 2020-03-16.

Each calendar day is an observational geometric unit: fixed taxi-zone centroids with geodesic metric, daily relative pickup frequencies as the probability measure. This is a sequence of empirical metric-measure spaces. Time-varying distributions are interpreted descriptively.

The finite signature uses sorted distance arrays for orders 2, 3 and 4. Sorting is permutation-invariant but can lose some incidence information for K >= 4; it is not a complete canonical representation and is not the infinite characteristic signature of the theorem. Landmark selection relies on geographic support only.

The two independent batches of 5000 tuples per day/order are sampling from the empirical daily measure with replacement; these give numerical V-statistic approximations, not the complete distinct-index U-statistic. The difference between batches is retained for numerical diagnostics. The birthday-type collision probability for m trips, k <= 4, is bounded by k(k-1)/(2m) under sampling of unique trip records, conditional on the empirical data.

CUSUM and positive block covariance Gaussian-bridge calculations follow the numerical structure of the latest synthetic simulation code. Block lengths 7,14,28 and raw/weekday-adjusted variants are predeclared sensitivity choices. Because stationarity and finite-range dependence have not been established, p-values are exploratory only. The fitted covariance can also be contaminated by an alternative.

The split location is descriptive; even a large CUSUM value is not direct proof of a structural change, and no causal interpretation is made. Source metadata: https://data.cityofnewyork.us/api/geospatial/8meu-9t5y?method=export&format=GeoJSON.
