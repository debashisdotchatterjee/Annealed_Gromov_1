# Automatically generated numerical evidence

This file is intended for subsequent manuscript drafting. Refer to CSV tables and plots; do not promote exploratory p-values to formal tests.

Days: 550; zone count: 260; event: 2020-03-16

|   max_order |   n_before |   n_after |   euclidean_signature_difference |   relative_to_pooled_mean |   mean_independent_tuple_disagreement |   maximum_independent_tuple_disagreement | note                                                                       |
|------------:|-----------:|----------:|---------------------------------:|--------------------------:|--------------------------------------:|-----------------------------------------:|:---------------------------------------------------------------------------|
|           2 |        259 |       291 |                        0.0113076 |                 0.0983352 |                            0.00204056 |                               0.00460424 | Descriptive contrast; not causal and not theorem-guaranteed inferential CI |
|           3 |        259 |       291 |                        0.0126678 |                 0.0688977 |                            0.00204056 |                               0.00460424 | Descriptive contrast; not causal and not theorem-guaranteed inferential CI |
|           4 |        259 |       291 |                        0.0131647 |                 0.0627831 |                            0.00204056 |                               0.00460424 | Descriptive contrast; not causal and not theorem-guaranteed inferential CI |

| representation   |   max_order |   block | estimated_split_date   |   exploratory_pvalue |
|:-----------------|------------:|--------:|:-----------------------|---------------------:|
| raw              |           2 |       7 | 2020-03-14             |           0.00333333 |
| raw              |           2 |      14 | 2020-03-14             |           0.00333333 |
| raw              |           2 |      28 | 2020-03-14             |           0.0166667  |
| raw              |           3 |       7 | 2020-03-14             |           0.00333333 |
| raw              |           3 |      14 | 2020-03-14             |           0.00333333 |
| raw              |           3 |      28 | 2020-03-14             |           0.0333333  |
| raw              |           4 |       7 | 2020-03-14             |           0.00333333 |
| raw              |           4 |      14 | 2020-03-14             |           0.00333333 |
| raw              |           4 |      28 | 2020-03-14             |           0.0433333  |
| weekday_adjusted |           2 |       7 | 2020-03-15             |           0.00333333 |
| weekday_adjusted |           2 |      14 | 2020-03-15             |           0.00333333 |
| weekday_adjusted |           2 |      28 | 2020-03-15             |           0.01       |
| weekday_adjusted |           3 |       7 | 2020-03-15             |           0.00333333 |
| weekday_adjusted |           3 |      14 | 2020-03-15             |           0.00333333 |
| weekday_adjusted |           3 |      28 | 2020-03-15             |           0.0166667  |
| weekday_adjusted |           4 |       7 | 2020-03-15             |           0.00333333 |
| weekday_adjusted |           4 |      14 | 2020-03-15             |           0.00333333 |
| weekday_adjusted |           4 |      28 | 2020-03-15             |           0.02       |