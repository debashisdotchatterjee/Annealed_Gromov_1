# How to interpret the outputs

- `01_exact/population_shifts.csv`: population shifts **given the finite dictionary**; they are not uniform theoretical detection guarantees.
- `02_monte_carlo/replicate_results.csv`: every calibrated replicate; raw checkpoints support reproducibility.
- `02_monte_carlo/summary_rates.csv`: estimated rejection frequencies with Wilson intervals. Null sizes should be compared with nominal 0.05; alternative rates estimate power.
- `03_figures`: export-ready PNG and PDF scientific figures.
- `04_diagnostics`: checks against full brute-force ordered U-statistic; bandwidth effect on *population* features, not selected by observed power.

The original Gaussian baseline is preserved. Invariant higher-order centres are fixed from the entire model-class vocabulary, not inferred from any simulated run. `patterns3` is a finite discrete-pattern comparator, distinct from the original Gaussian signature. `enhanced4` uses canonical four-point distance arrays rather than sorting all six distances (which would lose information). The covariance uses a prespecified memory-aware block length max(2(q+1),ceil(T^(1/3))+2). Calibration is asymptotic, not guaranteed exact at small T; q is known in the simulation, not assumed known in observational applications.

The numerical optimization applies to a finite four-support-point experiment: exact complete U-statistics from category counts, not an approximation to a continuous point-cloud algorithm. Increasing the number of Monte Carlo replications improves *precision* of size/power estimates, not the power of each fixed-sample test.
